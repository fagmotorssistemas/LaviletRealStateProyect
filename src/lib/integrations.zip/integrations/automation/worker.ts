import 'server-only'
import { randomUUID } from 'node:crypto'
import { assertLive, automationSettings } from './config'
import { autoConfig, db, object, rpc, scope, text, type Row } from './data'
import { processConversation } from './conversation'
import { pendingVisits, planVisits, previewVisits, sendVisit } from './visits'
import { ProviderError } from './kommo'
import { cancelNutrition24h, sendNutrition24h } from './nutrition'
import { cancelNutritionWeekOne, sendNutritionWeekOne } from './nutrition-week-one'
import { cancelNutritionLater, sendNutritionLater } from './nutrition-later'
import { NUTRITION_TASKS } from '@/lib/inmobiliaria/nutritionLater'
import { kommoDeliveryBlock, rejectedWriteStatus } from './delivery-state'
import { OpenAIRequestError } from './openai-request'
import { GenerationRecoveryError, recoverGenerationFailure } from './generation-recovery'
import { claimTestMessages } from './test-response-mode'
import { isCommercialContextReadFailure } from './context-read'
import { processAdvisorOutbound } from './advisor-outbound'

async function scheduleTasks() {
  const now = new Date()
  const day = new Intl.DateTimeFormat('en-CA', { timeZone: 'America/Guayaquil' }).format(now)
  const tasks = [{ ...scope, event_key: `maintenance:${now.toISOString().slice(0, 16)}`, kind: 'maintenance', payload: {} }]
  if (automationSettings().globalMaintenance && !automationSettings().testLeadId) {
    tasks.push({ ...scope, event_key: `decay:${day}`, kind: 'decay', payload: {} })
  }
  const { error } = await db().from('lv_integration_events').upsert(tasks, { onConflict: 'project_id,event_key', ignoreDuplicates: true })
  if (error) throw new Error('TASK_SCHEDULE_FAILED')
}

export async function runAutomation(testContact?: string) {
  const settings = automationSettings()
  if (settings.mode === 'off') return { mode: 'off', processed: 0 }
  if (settings.mode === 'preview') return { mode: 'preview', databaseWrites: false, visits: await previewVisits() }
  assertLive()
  const config = await autoConfig()
  if (config.enabled !== true || config.dry_run !== false) return { mode: 'live', processed: 0, reason: 'database_paused' }
  const token = randomUUID()
  if (await rpc('lv_app_worker_lock', { p_token: token, p_action: 'acquire' }) !== true) return { mode: 'live', processed: 0, reason: 'worker_busy' }
  const guard = async () => {
    assertLive()
    if (await rpc('lv_app_worker_lock', { p_token: token, p_action: 'renew' }) !== true) throw new Error('WORKER_LEASE_LOST')
  }
  const results: Row[] = [], started = Date.now()
  try {
    const block = await kommoDeliveryBlock()
    if (block) return { mode: 'live', processed: 0, reason: 'kommo_account_blocked', http_status: block.http_status }
    if(!testContact) await scheduleTasks()
    // Reservas abandonadas del nuevo ejecutor requieren revisión; nunca reenvío automático.
    if(!testContact) {
    const { error } = await db().from('lv_outbox').update({ status: 'uncertain', detail: 'Worker interrumpido; comprobar Kommo' })
      .match(scope).eq('status', 'claimed').contains('payload', { _app: 'lavilet' })
      .lt('claimed_at', new Date(Date.now() - 5 * 60_000).toISOString())
    if (error) throw new Error('STALE_OUTBOX_CHECK_FAILED')
    }
    for (let i = 0; i < 3 && Date.now() - started < 45_000; i++) {
      await guard()
      const batch = testContact ? await claimTestMessages(token,testContact) : await rpc<Row[]>('lv_app_claim', { p_token: token })
      if (!batch.length) break
      const first = object(batch[0]), ids = batch.map(row => row.id)
      try {
        let result: Row
        if (first.kind === 'advisor_outbound') {
          result = await processAdvisorOutbound(first)
        }
        else if (first.kind === 'inbound') {
          await guard()
          await cancelNutrition24h(Number(object(first.payload).kommoId))
          await cancelNutritionWeekOne(Number(object(first.payload).kommoId))
          await cancelNutritionLater(Number(object(first.payload).kommoId))
          result = await processConversation(batch, guard)
        }
        else if (first.kind === 'maintenance' && NUTRITION_TASKS.includes(text(object(first.payload).task))) {
          result = object(first.payload).task === 'nutrition_week_one' ? await sendNutritionWeekOne(first, guard)
            : object(first.payload).task === 'nutrition_24h' ? await sendNutrition24h(first, guard) : await sendNutritionLater(first, guard)
          if (result.action === 'deferred') {
            const { error } = await db().from('lv_integration_events').update({ status: 'pending', available_at: result.nextAt, claim_token: null, claimed_at: null })
              .match(scope).eq('id', first.id).eq('status', 'processing').eq('claim_token', token)
            if (error) throw Error('NUTRITION_DEFER_FAILED')
            results.push({ kind: object(first.payload).task, ...result })
            continue
          }
        }
        else if (first.kind === 'maintenance') {
          await guard()
          const enqueued = await planVisits(guard)
          // Estas RPC originales son globales. No ejecutarlas en modo de un lead de prueba.
          if (settings.globalMaintenance && !settings.testLeadId && config.test_only === false) {
            for (const name of ['lv_release_expired_holds', 'lv_escalate_overdue_requests', 'process_handoff_queue']) { await guard(); await rpc(name) }
          }
          result = { enqueued }
        } else if (first.kind === 'decay') {
          await guard()
          if (settings.globalMaintenance && !settings.testLeadId && config.test_only === false) await rpc('apply_temperature_decay')
          result = { action: 'daily_decay' }
        } else throw new Error('UNSUPPORTED_TASK')
        if (first.kind === 'inbound' && result.action === 'expired') {
          result = { ...result, reason: 'REPLY_WINDOW_EXPIRED', requires_review: true, delivery_status: 'not_sent' }
        }
        await rpc('lv_app_finish', { p_token: token, p_ids: ids,
          p_status: result.action === 'cancelled' || result.delivery_status === 'not_sent' ? 'cancelled' : 'completed', p_result: result })
        results.push({ kind: first.kind, ...result })
      } catch (error) {
        const generationFailure = error instanceof OpenAIRequestError
        let failure = error, recoveryUncertain = false
        if (generationFailure && first.kind === 'inbound') {
          try {
            const recovery = await recoverGenerationFailure(batch, guard, error.message)
            await rpc('lv_app_finish', { p_token: token, p_ids: ids,
              p_status: recovery.delivery_status === 'not_sent' ? 'cancelled' : 'completed', p_result: recovery })
            results.push({ kind: first.kind, ...recovery })
            continue
          } catch (recoveryError) {
            recoveryUncertain = !(recoveryError instanceof GenerationRecoveryError) || recoveryError.deliveryUncertain
            failure = recoveryError instanceof GenerationRecoveryError ? recoveryError.original : recoveryError
          }
        }
        // Una RPC o petición pudo ejecutar su efecto antes de fallar la conexión.
        // Guardar solo códigos propios, nunca cuerpos de proveedores o datos del cliente.
        const reason = failure instanceof Error && /^[A-Z0-9_]+$/.test(failure.message) ? failure.message : 'PROCESSING_FAILED'
        const rejected = failure instanceof ProviderError && !failure.uncertain && rejectedWriteStatus(failure.status)
        const detail = failure instanceof ProviderError ? { provider_operation: failure.operation, delivery_uncertain: failure.uncertain, http_status: failure.status } : {}
        const generationNotSent = generationFailure && !recoveryUncertain && !(failure instanceof ProviderError && failure.uncertain)
        const contextNotSent = isCommercialContextReadFailure(reason)
        // A rejected attempt stays visible for advisor review, but must not
        // permanently lock the contact as if a Salesbot might have been sent.
        const status = rejected || generationNotSent || contextNotSent ? 'cancelled' : 'uncertain'
        await rpc('lv_app_finish', { p_token: token, p_ids: ids, p_status: status,
          p_result: { reason, ...detail, requires_review: true, ...(generationFailure ? { generation_error: error.message } : {}),
            ...(rejected ? { delivery_status: 'rejected', recovery: 'not_replayed' }
              : generationNotSent ? { delivery_status: 'generation_failed' }
                : contextNotSent ? { delivery_status: 'not_sent', recovery: 'safe_read_failure' } : {}) } })
        results.push({ kind: first.kind, status, reason })
      }
      if (await kommoDeliveryBlock()) return { mode: 'live', processed: results.length, reason: 'kommo_account_blocked', results }
    }
    for (const job of testContact ? [] : await pendingVisits()) {
      if (Date.now() - started > 150_000) break
      await guard()
      results.push(await sendVisit(text(job.id), guard))
      if (await kommoDeliveryBlock()) break
    }
    return { mode: 'live', processed: results.length, results }
  } finally {
    // No libera el bloqueo de otro worker si nuestro arrendamiento ya expiró.
    await rpc('lv_app_worker_lock', { p_token: token, p_action: 'release' })
  }
}
